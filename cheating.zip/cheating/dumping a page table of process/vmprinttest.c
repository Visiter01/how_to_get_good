#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, "--- Initial vmprint ---\n");
  vmprint();

  printf(1, "\n--- After sbrk(8 * 4096) ---\n");
  sbrk(8 * 4096);
  vmprint();

  printf(1, "\n--- After sbrk(-4096) ---\n");
  sbrk(-4096);
  vmprint();

  exit();
}

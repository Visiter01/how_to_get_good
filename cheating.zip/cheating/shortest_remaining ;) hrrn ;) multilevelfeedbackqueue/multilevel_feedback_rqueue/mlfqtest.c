#include "types.h"
#include "user.h"

void cpu_bound() {
    printf(1, "CPU-bound process %d starting...\n", getpid());
    // Massive loop to burn through time slices
    for(int i = 0; i < 1000; i++) {
        for(int j = 0; j < 10000; j++) {
            asm("nop");
        }
    }
    printf(1, "CPU-bound process %d finished.\n", getpid());
    exit();
}

void io_bound() {
    printf(1, "I/O-bound process %d starting...\n", getpid());
    // Loop that frequently yields the CPU by sleeping
    for(int i = 0; i < 10; i++) {
        sleep(5); 
    }
    printf(1, "I/O-bound process %d finished.\n", getpid());
    exit();
}

int main() {
    printf(1, "Starting MLFQ Test...\n");
    
    // Fork two CPU hogs
    if(fork() == 0) cpu_bound();
    if(fork() == 0) cpu_bound();
    
    // Fork two interactive/IO processes
    if(fork() == 0) io_bound();
    if(fork() == 0) io_bound();
    
    // Wait for all 4 children to finish
    for(int i = 0; i < 4; i++) {
        wait();
    }
    
    printf(1, "MLFQ Test Complete.\n");
    exit();
}

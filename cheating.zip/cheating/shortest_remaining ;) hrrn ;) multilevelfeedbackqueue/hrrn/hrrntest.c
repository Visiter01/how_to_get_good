#include "types.h"
#include "user.h"

void cpu_bound_task(int loops) {
    // A heavy loop to keep the CPU busy
    for(int i = 0; i < loops * 10000; i++) asm("nop");
}

int main() {
    printf(1, "Starting HRRN Scheduler Test...\n");

    // Job A: The Initial Hog 
    // This job grabs the CPU first and holds it hostage so the others have to wait.
    if (fork() == 0) {
        sleep(5); // Sleep briefly so the parent can finish forking the others
        set_burst(getpid(), 1000);
        printf(1, "Job A (Hog) started\n");
        cpu_bound_task(1000);
        printf(1, "Job A (Hog) finished\n");
        exit();
    }
    
    // Job B: The Long Job (Arrives early, waits a long time)
    if (fork() == 0) {
        sleep(10); // Wakes up and enters ready queue while Job A is hogging the CPU
        set_burst(getpid(), 800);
        printf(1, "Job B (Long: 800) started\n");
        cpu_bound_task(800);
        printf(1, "Job B (Long: 800) finished\n");
        exit();
    }

    // Job C: The Short Job (Arrives later)
    if (fork() == 0) {
        sleep(50); // Wakes up later, but still while Job A is running
        set_burst(getpid(), 100);
        printf(1, "Job C (Short: 100) started\n");
        cpu_bound_task(100);
        printf(1, "Job C (Short: 100) finished\n");
        exit();
    }
    
    // Parent process waits for all 3 children to finish
    for(int i = 0; i < 3; i++) {
        wait();
    }

    printf(1, "HRRN Test Complete.\n");
    exit();
}

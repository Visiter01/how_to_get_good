#include "types.h"
#include "stat.h"
#include "user.h"

void heavy_workload(int id) {
  volatile double x = 0;
  for (int i = 0; i < 5000000; i++) {
    x = x + 3.14 * 89.64;
  }
  printf(1, "Process %d finished\n", id);
  exit();
}

int main() {
  printf(1, "Starting SJF Test...\n");
  for (int i = 1; i <= 4; i++) {
    int pid = fork();
    if (pid == 0) {
      // Process 1 gets largest burst (400), Process 4 gets smallest (100)[cite: 8]
      int burst = (5 - i) * 100;
      set_burst(getpid(), burst);
      printf(1, "Process %d starting with burst %d\n", i, burst);
      heavy_workload(i);
    } else {
      sleep(5); // Slight stagger[cite: 8]
    }
  }
  wait(); wait(); wait(); wait();
  printf(1, "All SJF processes completed.\n");
  exit();
}

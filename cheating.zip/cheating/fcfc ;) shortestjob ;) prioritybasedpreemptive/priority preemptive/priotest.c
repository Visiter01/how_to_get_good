#include "types.h"
#include "stat.h"
#include "user.h"

void heavy_workload(int id) {
  volatile double x = 0;
  for (int i = 0; i < 5000000; i++) {
    x = x + 3.14 * 89.64; // CPU-bound work
  }
  printf(1, "Process %d finished\n", id);
  exit();
}

int main() {
  printf(1, "Starting Priority Scheduler Test...\n");
  for (int i = 1; i <= 4; i++) {
    int pid = fork();
    if (pid == 0) {
      // Process 1 gets lowest priority (20), Process 4 gets highest (5)
      int prio = 25 - (i * 5); 
      set_priority(getpid(), prio);
      printf(1, "Process %d starting with priority %d\n", i, prio);
      heavy_workload(i);
    }
  }
  wait(); wait(); wait(); wait();
  printf(1, "All priority processes completed.\n");
  exit();
}

#include "types.h"
#include "user.h"

void cpu_bound_task(int loops) {
    for(int i = 0; i < loops * 10000; i++) asm("nop");
}

int main() {
    if(fork() == 0) {
        set_burst(getpid(), 500); // Long job
        printf(1, "Long Job started\n");
        cpu_bound_task(500);
        printf(1, "Long Job finished\n");
        exit();
    }
    
    sleep(50); // Stagger arrival
    
    if(fork() == 0) {
        set_burst(getpid(), 100); // Short job arriving later
        printf(1, "Short Job started (preempting)\n");
        cpu_bound_task(100);
        printf(1, "Short Job finished\n");
        exit();
    }
    
    wait(); 
    wait();
    exit();
}
